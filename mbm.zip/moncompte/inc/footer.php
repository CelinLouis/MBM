	<footer class="container-100 footer" style="-moz-box-shadow:0 5px 5px rgba(182, 182, 182, 0.75);
-webkit-box-shadow: 0 5px 5px rgba(182, 182, 182, 0.75);
box-shadow: 0 5px 5px rgba(182, 182, 182, 0.75); ">
		<div class="container-100-child flex-container">
			<div class="footer-networks">
				<a class="rss-feed" rel="nofollow" href="https://www.script-pag.com/demo/Pagrowoc/rss/Script-PAG-Demo.xml" target="_blank"></a>
				<a class="facebook-networks" href="https://www.facebook.com/Script.PAG/" target="_blank"></a>
				<a class="twitter-networks" href="https://twitter.com/ElinaWeb" target="_blank"></a>
				<a class="linkedin-networks" href="https://www.linkedin.com/company/elinaweb/" target="_blank"></a>
				<a class="instagram-networks" href="https://www.instagram.com/" target="_blank"></a>
				<a class="pinterest-networks" href="https://www.pinterest.com/" target="_blank"></a>
				<p>Copyright &copy; <b>Tsena MAIVA</b></p>
			</div>
			<div>
				<ul>
					<ul>
					<li><a href="info/Aide-1.html">Aide</a></li><li><a href="info/Regles-de-diffusion-2.html">Règles de diffusion</a></li><li><a href="../cond-utilisations.php">Conditions générales d'utilisation</a></li><li><a href="../cond-ventes.php">Conditions générales de vente</a></li><li><a href="info/Politique-de-confidentialite-5.html">Politique de confidentialité</a></li>
					<li><a href="send_contact.html">Nous contacter</a></li>
				</ul>
			</div>
				</ul>
			</div>
		</div>
	</footer>
	<script>
		var visit_latitude = 0;
		var visit_longitude = 0;
	</script>

	<script src="https://maps.google.com/maps/api/js?key=AIzaSyD0RVZcN60kwS2wIKJf3ck9MwG8s381bz0&amp;libraries=places&amp;callback=initMap" async defer></script>

	<script src="../js/jquery-3.1.1.js"></script>
	<script src="../js/jquery.validate.js"></script>
	<script src="../js/jquery-11.4.ui.min.js"></script>
	<script src="../js/functions_js.js"></script>
	<script src="../js/map.js"></script>
	<script src="../js/app.js"></script>
	<script src="../js/sweetalert.js"></script>
	<script src="../js/geolocalisation-depot.js"></script>

	<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

	<script src="../assets/js/app.min.js"></script>
	<script src="../assets/js/theme/default.min.js"></script>
	<!-- ================== END BASE JS ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
	
	<script src="../assets/fontawesome/js/fontawesome.js"></script>
	<script src="../assets/plugins/flot/jquery.flot.js"></script>
	<script src="../assets/plugins/flot/jquery.flot.time.js"></script>
	<script src="../assets/plugins/flot/jquery.flot.resize.js"></script>
	<script src="../assets/plugins/flot/jquery.flot.pie.js"></script>
	<script src="../assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
	<script src="../assets/plugins/jvectormap-next/jquery-jvectormap.min.js"></script>
	
	<script src="../assets/plugins/jvectormap-next/jquery-jvectormap-world-mill.js"></script>
	<script src="../assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.js"></script>
	<script src="../assets/js/demo/dashboard.js"></script>

	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
	<script src="../assets/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
	<script src="../assets/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
	<script src="../assets/plugins/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
	<script src="../assets/plugins/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
	<script src="../assets/plugins/datatables.net-autofill/js/dataTables.autofill.min.js"></script>
	<script src="../assets/plugins/datatables.net-autofill-bs4/js/autofill.bootstrap4.min.js"></script>
	<script src="../assets/plugins/datatables.net-colreorder/js/dataTables.colreorder.min.js"></script>
	<script src="../assets/plugins/datatables.net-colreorder-bs4/js/colreorder.bootstrap4.min.js"></script>
	<!--script src="../assets/plugins/datatables.net-keytable/js/dataTables.keytable.min.js"></script-->
	
	<script src="../assets/plugins/datatables.net-rowreorder/js/dataTables.rowreorder.min.js"></script>
	<script src="../assets/plugins/datatables.net-rowreorder-bs4/js/rowreorder.bootstrap4.min.js"></script>
	
	<script src="../assets/plugins/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
	<script src="../assets/plugins/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
	<script src="../assets/plugins/datatables.net-buttons/js/buttons.colVis.min.js"></script>
	<script src="../assets/plugins/datatables.net-buttons/js/buttons.flash.min.js"></script>
	<script src="../assets/plugins/datatables.net-buttons/js/buttons.html5.min.js"></script>
	<script src="../assets/plugins/datatables.net-buttons/js/buttons.print.min.js"></script>
	<script src="../assets/plugins/pdfmake/build/pdfmake.min.js"></script>
	<script src="../assets/plugins/pdfmake/build/vfs_fonts.js"></script>
	<script src="../assets/plugins/jszip/dist/jszip.min.js"></script>
	<script src="../assets/js/demo/table-manage-combine.demo.js"></script>
	<script src="../assets/plugins/superbox/jquery.superbox.min.js"></script>
	<script src="../assets/plugins/lity/dist/lity.min.js"></script>
	<script src="../assets/js/demo/profile.demo.js"></script>



	<script type="text/javascript">
		function modifierAnnonces(id_annonces){
			$("#modal-annonces").show();
		}
	</script>
	</body>
</html>

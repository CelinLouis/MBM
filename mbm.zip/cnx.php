<?php  
	$conn = new mysqli('localhost','bonbazar', '2D3ho$9k', 'karoka_blablacar');
	$conn->set_charset("utf8");
?>

<?php  
	include("include/header.php");
?>
<title>Formulaire</title>
<div class="container-100 header-end"></div>

<div class="container-100">
	<div class="container-100-child forms form-deposit">
	       <h2>Etapes 1 Offre</h2>  
	          	  
	          	   <form>
                     <h2>Bijou & Montre</h2>
	          	   	<div>
	          	   	
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Univers</option>
                     	<option>Homme</option>
                     	<option>Femme</option>
                     	<option>Enfant</option>
                     	<option>Mixte</option>
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Type</option>
                     	<option>Bague</option>
                     	<option>Bijou de téléphone</option>
                        <option>Bijou de tête</option>
                     	<option>Boucles d'oreilles</option>
                     	<option>Boutons de manchette</option>
                     	<option>Bracelet</option>
                     	<option>Broche</option>
                     	<option>Chaîne</option>
                     	<option>Charm</option>
                     	<option>Chevalière</option>
                     	<option>Collier, pendentif</option>
                     	<option>Gourmette</option>
                     	<option>Montre à gousset</option>
                     	<option>Montre automatique</option>
                     	<option>Montre connectée</option>
                     	<option>Montre de sport</option>
                     	<option>Montre mécanique</option>
                     	<option>Montre quartz</option>
                     	<option>Montre-bague</option>
                     	<option>Montre-pendentif</option>
                     	<option>Parure</option>
                     	<option>Piercing</option>
                     	<option>Autre</option>
                     </select>
                       <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Marque</option>
                     	<option>Aghata</option>
                     	<option>APM</option>
                        <option>Apple</option>
                     	<option>Aurelie Bidermann</option>
                     	<option>Baccarat</option>
                     	<option>Balaboosté</option>
                     	<option>Balenciaga</option>
                     	<option>Big Bang Bijoux</option>
                     	<option>Bijoux Vitcoria</option>
                     	<option>Blue Pearls</option>
                     	<option>Boucheron</option>
                     	<option>Breitling</option>
                     	<option>Bulgari</option>
                     	<option>Bulberry</option>
                     	<option>Calvin Klein</option>
                     	<option>Cartier</option>
                     	<option>Céline</option>
                     	<option>Cerruti 1881</option>
                     	<option>Chanel</option>
                     	<option>Chaumet</option>
                     	<option>Cléor</option>
                     	<option>Chopard</option>

                     	<option>Chritian Lacroix</option>
                     	<option>Clio Blue</option>
                     	<option>Cluse</option>
                     	<option>Daaniel Wellington</option>
                     	<option>Diesel</option>
                     	<option>Dinh Van</option>
                     	<option>Dior</option>
                     	<option>Dolce & Gabanna</option>
                     	<option>Fendi</option>
                     	<option>Festina</option>
                     	<option>Fossil</option>
                     	<option>Fred</option>
                     	<option>Gas Bijoux</option>
                     	<option>Gigi Clozeau</option>
                     	<option>Ginette NY</option>
                     	<option>Givenchy</option>
                     	<option>Gucci</option>
                     	<option>Guess</option>
                     	<option>Autre</option>
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Matière</option>
                     	<option>Acier</option>
                     	<option>Argent</option>
                     	<option>Bois</option>
                     	<option>Céramique</option>
                     	<option>Cuir</option>
                        <option>Diamant</option>
                     	<option>Doré</option>
                     	<option>Métal</option>
                     	<option>Or blanc</option>
                     	<option>Or jaune</option>
                     	<option>Or jaune & blanc</option>
                     	<option>Or rose</option>
                     	<option>Perles</option>
                     	<option>Pierre</option>
                     	<option>Plaqué or</option>
                        <option>Tussi</option>
                     	<option>Titan</option>
                     	<option>Plastique</option>
                     	<option>Autre</option>
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>État</option>
                     	<option>Etat neuf</option>
                     	<option>Très bon état</option>
                     	<option>Bon état</option>
                     	<option>Etat moyen</option>
                     </select>


	          	    </div>
	          	   	
	          	   </form>
	                

	          	   <form>
 <h2>Vetement</h2>
	          	   	<div>
	          	   	
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Univers</option>
                     	<option>Homme</option>
                     	<option>Femme</option>
                     	<option>Enfant</option>
                     	<option>Mixte</option>
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Taille</option>
                     	
                     	<option>Autre</option>
                     </select>
                       <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Type de Vêtement</option>
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Marque</option>
                     	
                     	<option>Autre</option>
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Couleur</option>
                     	
                     </select>
                      <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Etat</option>
                     	<option>Etat neuf</option>
                     	<option>Très bon état</option>
                     	<option>Bon état</option>
                     	<option>Etat moyen</option>
                     </select>


	          	    </div>
	          	   	
	          	   </form>


	          	     <form>
 <h2>Chaussures</h2>
	          	   	<div>
	          	   	
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Univers</option>
                     	<option>Homme</option>
                     	<option>Femme</option>
                     	<option>Enfant</option>
                     	<option>Mixte</option>
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Type de chaussure</option>
                     	
                     	<option>Autre</option>
                     </select>
                       <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Pointure</option>
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Marque</option>
                     	
                     	<option>Autre</option>
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Couleur</option>
                     	
                     </select>
                      <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Etat</option>
                     	<option>Etat neuf</option>
                     	<option>Très bon état</option>
                     	<option>Bon état</option>
                     	<option>Etat moyen</option>
                     </select>


	          	    </div>
	          	   	
	          	   </form>

	          	      <form>
 <h2>Accessoires & Bagagerie</h2>
	          	   	<div>
	          	   	
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Univers</option>
                     	<option>Homme</option>
                     	<option>Femme</option>
                     	<option>Enfant</option>
                     	<option>Mixte</option>
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Type</option>
                     	
                     	<option>Autre</option>
                     </select>
                       <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Marque</option>
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Matière</option>
                     	
                     	<option>Autre</option>
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Couleur</option>
                     	
                     </select>
                      <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Etat</option>
                     	<option>Etat neuf</option>
                     	<option>Très bon état</option>
                     	<option>Bon état</option>
                     	<option>Etat moyen</option>
                     </select>


	          	    </div>
	          	   	
	          	   </form>


	          	      <form>
 <h2>Equipement bébé</h2>
	          	   	<div>
	          	   	
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Type</option>
                     	
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Marque</option>
                     	<option>Autre</option>
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Couleur</option>
                     </select>
                      <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Etat</option>
                     	<option>Homme</option>
                     	<option>Femme</option>
                     	<option>Enfant</option>
                     	<option>Mixte</option>
                     </select>


	          	    </div>
	          	   	
	          	   </form>



	          	      <form>
 <h2>Vêtements bébé</h2>
	          	   	<div>
	          	   	
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Types de vêtement</option>
                     	
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Taille</option>
                     	
                     	<option>Autre</option>
                     </select>
                       <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Marque</option>
                     </select>
                     
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Couleur</option>
                     	
                     </select>
                      <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Etat</option>
                     	<option>Etat neuf</option>
                     	<option>Très bon état</option>
                     	<option>Bon état</option>
                     	<option>Etat moyen</option>
                     </select>


	          	    </div>
	          	   	
	          	   </form>



	          	      <form>
 <h2>Décoration</h2>
	          	   	<div>
	          	   	
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Type</option>
                     	
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Matière</option>
                     	
                     	<option>Autre</option>
                     </select>
                       
                     
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Couleur</option>
                     	
                     </select>
                      <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Etat</option>
                     	<option>Etat neuf</option>
                     	<option>Très bon état</option>
                     	<option>Bon état</option>
                     	<option>Etat moyen</option>
                     </select>


	          	    </div>
	          	   	
	          	   </form>



	          	      <form>
 <h2>Jardinage</h2>
	          	   	<div>
	          	   	
                     
                      <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Etat</option>
                     	<option>Etat neuf</option>
                     	<option>Très bon état</option>
                     	<option>Bon état</option>
                     	<option>Etat moyen</option>
                     </select>


	          	    </div>
	          	   	
	          	   </form>


	          	    <form>
 <h2>Bricolage</h2>
	          	   	<div>
	          	   	
                     
                      <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Etat</option>
                     	<option>Etat neuf</option>
                     	<option>Très bon état</option>
                     	<option>Bon état</option>
                     	<option>Etat moyen</option>
                     </select>


	          	    </div>
	          	   	
	          	   </form>


                   <form>
 <h2>Arts de la table</h2>
	          	   	<div>
	          	   	
                     
                      <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Etat</option>
                     	<option>Etat neuf</option>
                     	<option>Très bon état</option>
                     	<option>Bon état</option>
                     	<option>Etat moyen</option>
                     </select>


	          	    </div>
	          	   	
	          	   </form>


	          	     <form>
 <h2>Linge de maison</h2>
	          	   	<div>
	          	   	
                     
                      <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Etat</option>
                     	<option>Etat neuf</option>
                     	<option>Très bon état</option>
                     	<option>Bon état</option>
                     	<option>Etat moyen</option>
                     </select>


	          	    </div>
	          	   	
	          	   </form>

	          	    <form>
 <h2>Electroménager</h2>
	          	   	<div>
	          	   	
                     
                      <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Etat</option>
                     	<option>Etat neuf</option>
                     	<option>Très bon état</option>
                     	<option>Bon état</option>
                     	<option>Etat moyen</option>
                     </select>


	          	    </div>
	          	   	
	          	   </form>


	          	   	      <form>
 <h2>Ameublement</h2>
	          	   	<div>
	          	   	
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Type</option>
                     	
                     </select>
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Matière</option>
                     	
                     	<option>Autre</option>
                     </select>
                       
                     
                     <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Couleur</option>
                     	
                     </select>
                      <select id="options" name="cat" class="short" onchange="DisplayOptions(); DisplayNote(); DisplayPrice(); DisplayCalendar(); DisplayFile()">
                     	<option>Etat</option>
                     	<option>Etat neuf</option>
                     	<option>Très bon état</option>
                     	<option>Bon état</option>
                     	<option>Etat moyen</option>
                     </select>


	          	    </div>
	          	   	
	          	   </form>



	          	    <form>
 <h2>Etapes 2</h2>
	          	   	<div>
	          	   	
                     <input type="text" name=""  class="short" placeholder="Titre de l'annonce"><br>
                     <label>Description de l'annonce
                                                            </label>
                     <textarea style="height: 200px"></textarea>

	          	    </div>
	          	   	
	          	   </form>




	          	    <form>
 <h2>Offres d'emploi</h2>
	          	   	<div>
	          	   	
                     <input type="text" name=""  class="short" placeholder="Poste recherché"><br>
                     <label>Description de vos expériences
                                                            </label>
                     <textarea style="height: 200px"></textarea>

	          	    </div>
	          	   	
	          	   </form>
	</div>
</div>

<?php  
	include("include/footer.php");
?>
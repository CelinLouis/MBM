<?php 
	echo $_POST['options'];
 ?>
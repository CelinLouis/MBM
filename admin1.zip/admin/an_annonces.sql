-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 19, 2020 at 12:34 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `karoka_blablacar`
--

-- --------------------------------------------------------

--
-- Table structure for table `an_annonces`
--

DROP TABLE IF EXISTS `an_annonces`;
CREATE TABLE IF NOT EXISTS `an_annonces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_membres` int(11) DEFAULT NULL,
  `an_souscat` text DEFAULT NULL,
  `an_type` text DEFAULT NULL,
  `an_title` text DEFAULT NULL,
  `an_desc` text DEFAULT NULL,
  `an_marquev` text DEFAULT NULL,
  `an_kmeterv` text DEFAULT NULL,
  `an_kmeterm` text DEFAULT NULL,
  `an_kmeterc` text DEFAULT NULL,
  `an_anneev` text DEFAULT NULL,
  `an_anneem` text DEFAULT NULL,
  `an_anneec` text DEFAULT NULL,
  `an_energyv` text DEFAULT NULL,
  `an_energyc` text DEFAULT NULL,
  `an_vitessev` text DEFAULT NULL,
  `an_cylinder` text DEFAULT NULL,
  `an_vitessec` text DEFAULT NULL,
  `an_surfacevm` text DEFAULT NULL,
  `an_surfacelm` text DEFAULT NULL,
  `an_surfacet` text DEFAULT NULL,
  `an_surfacelv` text DEFAULT NULL,
  `an_surfacecl` text DEFAULT NULL,
  `an_surfaceg` text DEFAULT NULL,
  `an_surfacel` text DEFAULT NULL,
  `an_surfacebc` text DEFAULT NULL,
  `an_piecevm` text DEFAULT NULL,
  `an_piecelm` text DEFAULT NULL,
  `an_piececl` text DEFAULT NULL,
  `an_piecelv` text DEFAULT NULL,
  `an_piecel` text DEFAULT NULL,
  `an_piecebc` text DEFAULT NULL,
  `an_capacityvm` text DEFAULT NULL,
  `an_capacitylm` text DEFAULT NULL,
  `an_capacitycl` text DEFAULT NULL,
  `an_capacitylv` text DEFAULT NULL,
  `an_debutlv` text DEFAULT NULL,
  `an_finlv` text DEFAULT NULL,
  `an_genref` text DEFAULT NULL,
  `an_genrem` text DEFAULT NULL,
  `an_nombref` text DEFAULT NULL,
  `an_nombrem` text DEFAULT NULL,
  `an_temploi` text DEFAULT NULL,
  `an_tcours` text DEFAULT NULL,
  `an_cporte` text DEFAULT NULL,
  `an_tporte` text DEFAULT NULL,
  `an_pporte` text DEFAULT NULL,
  `an_cmonbij` text DEFAULT NULL,
  `an_mmonbij` text DEFAULT NULL,
  `an_pmonbij` text DEFAULT NULL,
  `an_imgson` text DEFAULT NULL,
  `an_info` text DEFAULT NULL,
  `an_tel` text DEFAULT NULL,
  `an_jeu` text DEFAULT NULL,
  `an_price` text DEFAULT NULL,
  `an_region` text DEFAULT NULL,
  `an_city` text NOT NULL,
  `an_postcode` text NOT NULL,
  `an_address` text NOT NULL,
  `an_cond` text DEFAULT NULL,
  `an_photo1` text DEFAULT NULL,
  `an_photo2` text DEFAULT NULL,
  `an_photo3` text DEFAULT NULL,
  `an_photo4` text DEFAULT NULL,
  `an_photo5` text DEFAULT NULL,
  `an_photo6` text DEFAULT NULL,
  `an_photo7` text DEFAULT NULL,
  `an_photo8` text DEFAULT NULL,
  `an_datenreg` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `an_annonces`
--

INSERT INTO `an_annonces` (`id`, `id_membres`, `an_souscat`, `an_type`, `an_title`, `an_desc`, `an_marquev`, `an_kmeterv`, `an_kmeterm`, `an_kmeterc`, `an_anneev`, `an_anneem`, `an_anneec`, `an_energyv`, `an_energyc`, `an_vitessev`, `an_cylinder`, `an_vitessec`, `an_surfacevm`, `an_surfacelm`, `an_surfacet`, `an_surfacelv`, `an_surfacecl`, `an_surfaceg`, `an_surfacel`, `an_surfacebc`, `an_piecevm`, `an_piecelm`, `an_piececl`, `an_piecelv`, `an_piecel`, `an_piecebc`, `an_capacityvm`, `an_capacitylm`, `an_capacitycl`, `an_capacitylv`, `an_debutlv`, `an_finlv`, `an_genref`, `an_genrem`, `an_nombref`, `an_nombrem`, `an_temploi`, `an_tcours`, `an_cporte`, `an_tporte`, `an_pporte`, `an_cmonbij`, `an_mmonbij`, `an_pmonbij`, `an_imgson`, `an_info`, `an_tel`, `an_jeu`, `an_price`, `an_region`, `an_city`, `an_postcode`, `an_address`, `an_cond`, `an_photo1`, `an_photo2`, `an_photo3`, `an_photo4`, `an_photo5`, `an_photo6`, `an_photo7`, `an_photo8`, `an_datenreg`) VALUES
(2, 15, '7', 'Offre', 'Voiture Ferrari', 'Je vend ma voiture a bas prix', '0', '', '', '', '0', '0', '0', '0', '0', '0', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '100000000', '11', 'Mahajanga', '401', 'Antanimalandy', '1', 'annonces/images/j64707t941.jpg', 'annonces/images/j64707t941.jpg', '', '', '', '', '', '', '2020-03-08 13:37:02'),
(3, 15, '30', 'Offre', 'Film', 'dsqdqsd', '0', '', '', '', '0', '0', '0', '0', '0', '0', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', '0', '12', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '122222', '12', 'Mahajanga', '401', 'Antanimalandy', '1', 'annonces/images/film.jpg', '', '', '', '', '', '', '', '2020-03-08 14:13:23'),
(4, 16, '1', 'Offre', 'JOLIE BMW ETAT IMPECCABLE', 'JE QUITE HELAS MADAGASCAR POUR RAISON DE SANTE ET DE CE FAIT JE  VENDS  MA SUPERBE VOITURE .\nPAIEMENT EN PLUSIEURS MENSUALITES POSSIBLE \n', 'BMW', '220000', '', '', '2015', '0', NULL, 'Essence', NULL, '2', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '14999997', '11', 'MAJUNGA', '', 'VILLA BANCHE  FACE CHEZ NONO PORT SCHEIDER', '1', 'annonces/images/Capture d’écran 2020-03-14 à 14.53.02.png', 'annonces/images/Capture d’écran 2020-03-14 à 14.54.24.png', '', '', '', '', '', '', '2020-03-14 12:55:13'),
(5, 16, '5', 'Offre', 'CATAMARAN 14M HARRAM 56 PIEDS', ' A VENDRE UN CATAMARAN DE 14M , 4 CABINES  NOMBREUX ACCESSOIRES ,PRIX RAISONNABLE ME CONTACTER UNIQUEMENT PAR MAIL yaplukafer@gmaill.com ', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '100000000', '11', 'Majunga', '401', 'Majunga Mahajanga Rural', '1', 'annonces/images/IMG_20200313_153809.jpg', 'annonces/images/IMG_20200312_174253_618.jpg', 'annonces/images/IMG_20200313_153929.jpg', '', '', '', '', '', '2020-03-14 13:09:14'),
(6, 16, '17', 'Offre', 'APPRENDRE L ANGLAIS FACILEMENT AVEC MOI', 'BRJ SPECIALISEE DANS L APPRENTISSAGE DE L\' ANGLAIS JE DONNE DES COURS DU SOIR  A DOMICILE \nTARIF REDUIT ME CONTACTER \nLE PRIX INDIQUE EST PAR HEURE ...', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', 'soir', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '50000', '2', 'Tananarive', '', 'HOTEL MERCURE ', '1', 'annonces/images/80659726_2630704607011546_3680484632744165376_n.jpg', '', '', '', '', '', '', '', '2020-03-14 13:22:26'),
(7, 16, '2', 'Demande', 'CHERCHE MOTO PETER ', 'JE RECHERCHE UNE MOTO PETER 125 CM3 BON ETAT', '0', '', '5000', '', '0', '2019', NULL, '0', NULL, '0', '125', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '1000000', '2', '', '', '', '1', 'annonces/images/Capture d’écran 2020-03-14 à 15.33.56.png', '', '', '', '', '', '', '', '2020-03-14 13:34:08'),
(8, 16, '7', 'Offre', 'VENDS DEUX VELOS HOMME', 'JE VENDS DEUX VELOS HOMMES AVEC LES ROUES ETC', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '1900000', '13', 'Mahajanga', '', '', '1', 'annonces/images/Capture d’écran 2020-03-14 à 15.39.30.png', '', '', '', '', '', '', '', '2020-03-14 13:40:40'),
(9, 16, '8', 'Demande', 'RECHERCHE VILLA BORD DE MER', 'JE RECHERCHE EN LOCATION UNE VILLA BORD DE MER A PETITE PLAGE AVEC PISCINE , POUR AOUT 2020', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '348', '', '', '', '', '', '', '', '5', '', '', '', '', '', '9', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '2000000', '11', 'Majunga', '', '', '1', 'annonces/images/Capture d’écran 2020-03-14 à 15.45.31.png', '', '', '', '', '', '', '', '2020-03-14 13:45:55'),
(10, 16, '9', 'Demande', 'VILLA', 'JE RECHERCHE VILLA 5 CHAMBRES ETC ETC ', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '250', '', '', '', '', '', '', '', '6', '', '', '', '', '', '8', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '2000000', '11', 'Paris', '', '', '1', '', '', '', '', '', '', '', '', '2020-03-14 13:49:39'),
(11, 15, '1', 'Offre', 'BMW', 'Je vends ma BMW', 'BMW', '300', '', '', '2013', '0', NULL, 'Essence', NULL, '1', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '120000000', '11', 'Mahajanga', '401', 'Antanimalandy', '1', 'annonces/images/380027_BMW_8_Series.jpg', '', '', '', '', '', '', '', '2020-03-15 11:56:38'),
(12, 16, '9', 'Offre', 'SUPERBE VILLA A MAJUNGA', 'GFUYRIUTBRVITTBRYRYRT\nKIUY GUUTYY  \nG IUTUTUT\nIUIOYBIUYTTUYTUTURTRYT2', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '350', '', '', '', '', '', '', '', '5', '', '', '', '', '', '8', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '2000000', '11', 'MAHAJUNGA', '401', 'PORT SCHNEIDER', '1', 'annonces/images/Capture d’écran 2020-03-14 à 15.45.31.png', '', '', '', '', '', '', '', '2020-03-15 13:10:33'),
(13, 16, '16', 'Demande', 'UN POSTE DE SERVEUSE', 'GFYGUGYGGIGU\nIU,OMUO\nCV\nTEL 56789056\nSALAIRE A LA JOURNEE', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', 'permanent', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '10000', '13', 'DIEGO SUAREZ', '', '/KJLMKJMOUOHOMIYIHIHI', '1', 'annonces/images/36474740_1887294724903287_8657199852939116544_n.jpg', '', '', '', '', '', '', '', '2020-03-15 13:16:18'),
(14, 16, '24', 'Offre', 'SUPERBE TELEPHONE NEUF IP33', 'HTFIYGUBTUTIYOU\nUIPOYNYIYIYI\nME CONTACTER 0657886565', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', 'android', '0', '300000', '11', 'Mahajanga', '', '', '1', 'annonces/images/Capture d’écran 2020-03-15 à 15.24.23.png', '', '', '', '', '', '', '', '2020-03-15 13:24:43'),
(15, 16, '27', 'Offre', 'MACHINE A LAVER', 'MACHINE A LAVER , PRESQUE NEUVE , 9kG , ESSORAGE ENTRE 300 ET 1200 TOURS MINUTE\nACHETEE EN JANVIER 2020, VENTE POUR RAISON DE DEPART VERS LA FRANCE \nME CONTACTER PAR MAIL yaplukafer@gmail.com ou par telephone 0325687059\nlivraison possible ', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '1800000', '6', 'Tananarive', '', '', '1', 'annonces/images/Capture d’écran 2020-03-15 à 16.11.03.png', '', '', '', '', '', '', '', '2020-03-15 14:10:58'),
(16, 16, '4', 'Offre', 'CASQUE MOTO', 'JE VENDS CASQUE MOTO NEUF ', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '150000', '1', '', '', '', '1', 'annonces/images/Capture d’écran 2020-03-15 à 16.17.49.png', '', '', '', '', '', '', '', '2020-03-15 14:17:56'),
(17, 16, '10', 'Offre', 'TERRAIN A  NOSY BE', 'KJHILUYXGIZXUOZUX KGKUTOZUX HJGS 4000\n\n10000 AR LE M2', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '4000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '40000000', '13', 'HELL VILLE', '', '10 RUE DU PORT', '1', 'annonces/images/Capture d’écran 2020-03-15 à 16.46.50.png', '', '', '', '', '', '', '', '2020-03-15 14:47:12'),
(18, 16, '7', 'Offre', 'vends vélo', 'hfhjgjtkut kutkutk uf hdhfjr gt, rfytt,y;j tuyt tytkb jt, bj,h,gf &àà10000000 ARKHKYLHLK', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '1 000 000', '1', 'MAHAJUNGA', '401', 'PORT SCHNEIDER', '1', 'annonces/images/Capture d’écran 2020-03-16 à 09.05.09.png', '', '', '', '', '', '', '', '2020-03-16 07:05:33'),
(19, 16, '26', 'Offre', 'TABLE ET 4 CHAISES', ',YHNITSXSTXSG XSXGUKSTXSBSXSTXTYSXYSXTSBXYSJSXTJSJX', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '1 000 000', '1', '', '', '', '1', 'annonces/images/Capture d’écran 2020-03-16 à 09.15.29.png', '', '', '', '', '', '', '', '2020-03-16 07:15:36'),
(20, 16, '2', 'Offre', 'JOLIE MOTO  HONDA 250 CC', 'hbjktgbjbt kytuytbuytitgktcdg,dhc,hg dc,,dcfncd ,dfc,hdgcndvbc,ndhcnbdjzghnbvcfdcbvzcz dc', '0', '', '5000', '', '0', '2018', NULL, '0', NULL, '0', '250', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '3 000 000', '13', 'Antisiranana', '', '', '1', 'annonces/images/Capture d’écran 2020-03-16 à 09.22.47.png', '', '', '', '', '', '', '', '2020-03-16 07:23:19'),
(21, 16, '9', 'Offre', 'LOCATION MAISON A MAJUNGA', 'GHJHFJYFJTFHFDGFDFGDDFSFDSFDDXBNCGDBNVB,NVF,B,.G, 800 000 AR PAR MOIS CHARGE COMPRISES', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '100', '', '', '', '', '', '', '', '5', '', '', '', '', '', '4', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '800 000', '11', 'Mahajanga', '401', 'BD MARCOS', '1', 'annonces/images/Capture d’écran 2020-03-16 à 09.32.19.png', '', '', '', '', '', '', '', '2020-03-16 07:32:19'),
(22, 16, '15', 'Demande', 'BUREAU ', 'JE RECHERCHE UN PETIT LOCAL DE  10 M2 POUR CREER UNE AGENCE  DE LOCATION \nLE LOYER MENSUEL  DOIT ETRE INFERIEUR A 200 000 AR\nME CONTACTER AU PLUS VITE ', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '30', '', '', '', '', '', '1', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '200 000', '5', '', '', '', '1', 'images/no_photo1.png', '', '', '', '', '', '', '', '2020-03-17 08:18:06'),
(23, 16, '19', 'Offre', 'VENTE DE CHAUSSURES FEMME ', 'NOMBREUSES  CHAUSSURES A VENDRE ', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', 'chaussure', 'neuf', 'femme', '0', 'argent', '0', '0', '0', '0', '0', '20 000', '1', '', '', '', '1', 'images/no_photo1.png', '', '', '', '', '', '', '', '2020-03-17 08:23:09'),
(24, 16, '33', 'Offre', 'JEUX D ECHEC ', 'A VENDRE MAGNIFIQUE JEUX ECHEC EN PALISSANDRE FAIRE OFFRE LIVRAISON POSSIBLE  \n\n', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '50 000', '11', 'Mahajanga', '', 'GRDHGDJDFJY DF', '1', 'annonces/images/Capture d’écran 2020-03-17 à 10.28.19.png', '', '', '', '', '', '', '', '2020-03-17 08:28:25'),
(25, 16, '4', 'Offre', 'EMBRAYAGE WW NEUF', 'A VENDRE EMBRAYAGE NEUF POUR WW \nPETIT PRIX LIVRAISON POSSIBLE \nME CONTACTER PAR MESSAGERIE MBM', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '100 000', '19', '', '', '', '1', 'annonces/images/Capture d’écran 2020-03-20 à 10.38.05.png', '', '', '', '', '', '', '', '2020-03-20 08:38:09'),
(26, 16, '14', 'Offre', 'JE PROPOSE UN GARAGE A CONSTRUIRE ', 'JE VENDS UN GARAGE EN TOLE , IL EST COMPLET , PRET A ETRE CONSTRUIT\nIL EST CONSTITUE DUNE CHARPENTE ET DE 45 TOLES ONDULEES \nFACILE A MONTER \nPRIX INTERESSANT ME CONTACTER PAR LA MESSAGERIE \nLIVRAISON POSSIBLE \nPAIEMENT PAR ORANGE MONEY ', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '30', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '2 000 000', '19', '', '', '', '1', 'annonces/images/Capture d’écran 2020-03-20 à 10.43.13.png', '', '', '', '', '', '', '', '2020-03-20 08:43:21'),
(27, 16, '21', 'Demande', 'JE RECHERCHE MONTRE OR HOMME', 'JE RECHERCHE MONTRE OR HOMME FAIRE OFFRE \nURGENT \nPAIEMENT SUR PLACE APRES EXPERTISE\nME CONTACTER RAPIDEMENT AU TELEPHONE ', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', 'montre', 'autre', 'homme', '0', '0', '0', '0', '1 000 000', '20', '', '', '', '1', 'images/no_photo1.png', '', '', '', '', '', '', '', '2020-03-20 08:48:09'),
(28, 16, '20', 'Offre', 'A VENDRE SIEGE AUTO ENFANT', 'A VENDRE SIEGE AUTO ENFANT \n25KG MAXI \nSIEGE COMME NEUF CAR PEU SERVI \nME CONTACTER \n', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '500 000', '17', '', '', '', '1', 'annonces/images/Capture d’écran 2020-03-20 à 10.51.20.png', '', '', '', '', '', '', '', '2020-03-20 08:51:00'),
(29, 16, '32', 'Offre', 'COLLECTION TINTIN', 'AV COLLECTION TINTIN ONZE LIVRES ETAT MOYEN ', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '110 000', '9', '', '', '', '1', 'images/no_photo1.png', '', '', '', '', '', '', '', '2020-03-20 08:54:50'),
(30, 16, '32', 'Offre', 'COLLECTION ASTERIX ET OBELIX', 'COLLECTION BON ETAT FAIRE OFFRE ', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '200 000', '18', '', '', '', '1', 'annonces/images/Capture d’écran 2020-03-20 à 10.58.29.png', '', '', '', '', '', '', '', '2020-03-20 08:58:12'),
(31, 0, '10', 'Offre', 'TERRAIN BORD DE MER', '.NLKNSLDCJLJD C JDLC\nLCùDCKDMLKC\n\nML,C,ZE', '0', '', '', '', '0', '0', NULL, '0', NULL, '0', '', NULL, '', '', '1000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '35 000 000', '11', 'Mahajanga', '401', 'KHKZOHOZKI CHEZ KARON', '1', 'images/no_photo1.png', '', '', '', '', '', '', '', '2020-04-19 16:38:24'),
(32, 16, '1', 'Offre', ' A VENDRE VOITURE', 'HFYITRUC RYIRF5UVTUYUY6O6UB66BYMO8J8O7%JLKNYHKYBHRRM%OIIM', 'Daewoo', '100000', '', '', 'avant 2000', '0', NULL, 'Essence', NULL, '2', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '', '', '0', '0', '0', '0', '0', '0', 'argent', '0', '0', '0', '0', '0', '8 000 000', '1', 'MAHAJUNGA  MADAGASCAR', '401', 'rue des  manguiers', '1', 'annonces/images/Capture d’écran 2020-04-25 à 16.47.02.png', '', '', '', '', '', '', '', '2020-04-25 15:48:10');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
    include "includes/header.php";
    
    include "includes/navbar.php";

    include "includes/sidebar.php";
?>
<?php 
    $servername = "localhost";
    $username = "root";
    $password = "";

    // Create connection
    $conn = new mysqli($servername, $username, $password);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    echo "Connected successfully";

?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="far fa-comment"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Messages Directes</span>
                <span class="info-box-number">
                 0
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
           <?php 
             $select_favorie = "SELECT COUNT(*) cout FROM an_favori WHERE 1";
             $favorie = $conn->query($select_favorie);
            
          ?>
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-danger elevation-1"><!--<i class="fas fa-thumbs-up"></i>--><i class="fas fa-heart"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Annonces Favorites</span>
                <span class="info-box-number">0</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->

          <!-- fix for small devices only -->
          <div class="clearfix hidden-md-up"></div>

          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-success elevation-1"><i class="fas fa-shopping-cart"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Articles Vendues</span>
                <span class="info-box-number">0</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <?php 
             $select_membre = "SELECT COUNT(*) cout FROM membres WHERE 1";
             $membre = $conn->query($select_membre);
            
          ?>
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-users"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Membres</span>
                <span class="info-box-number">0</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->

         <div class="row">
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
               <div class="info-box mb-3 ">
                
                <div class="info-box-content">
                  <span class="info-box-text">Achats en attente de paiement</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
              <div class="info-box mb-3 ">
                
                <div class="info-box-content">
                  <span class="info-box-text">Annonces en attente de paiement</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
              <div class="info-box mb-3 ">
                
                <div class="info-box-content">
                  <span class="info-box-text">Annonces en attente de validation</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
              <div class="info-box mb-3 ">
                
                <div class="info-box-content">
                  <span class="info-box-text">Annonces validées</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
               <div class="info-box mb-3 ">
                
                <div class="info-box-content">
                  <span class="info-box-text">Annonces refusées</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
              <div class="info-box mb-3 ">
                
                <div class="info-box-content">
                  <span class="info-box-text">Annonces non confirmées</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
              <div class="info-box mb-3 ">
                
                <div class="info-box-content">
                  <span class="info-box-text">Annonces retirées</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
              <div class="info-box mb-3 ">
                
                <div class="info-box-content">
                  <span class="info-box-text">Annonces expirées</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
               <div class="info-box mb-3 ">
                
                <div class="info-box-content">
                  <span class="info-box-text">Comptes membre en attente de validation</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
              <div class="info-box mb-3 ">
                
                <div class="info-box-content">
                  <span class="info-box-text">Comptes membre validés</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
              <div class="info-box mb-3 ">
                
                <div class="info-box-content">
                  <span class="info-box-text">Comptes membre Refusés</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
              <div class="info-box mb-3 ">
                
                <div class="info-box-content">
                  <span class="info-box-text">Comptes membre non confirmés</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
               <div class="info-box mb-3 ">
                
                <div class="info-box-content">
                  <span class="info-box-text">Comptes pro en attente de validation</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
              <div class="info-box mb-3 ">
                
                <div class="info-box-content">
                  <span class="info-box-text">Compte pro validés</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
              <div class="info-box mb-3 ">
                <div class="info-box-content">
                  <span class="info-box-text">Comptes pro Refusés</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>
            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
              <div class="info-box mb-3 ">
                <div class="info-box-content">
                  <span class="info-box-text">Comptes pro non confirmés</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
            </a>
            </div>

            <div class="col-sm-6 col-md-4">
              <a style="color: black;" href="">
                <div class="info-box mb-3 ">
                <div class="info-box-content">
                  <span class="info-box-text">Vitrines en ligne</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
              </a>
            </div>

            <div class="col-sm-6 col-md-4">
            <a href="" style="color: black;">
              <div class="info-box mb-3 ">
                <div class="info-box-content">
                  <span class="info-box-text">Copie des mails envoyés</span>
                  <span class="info-box-number">0</span>
                </div>
                <!-- /.info-box-content -->
              </div>
              </a>
            </div>
            
        </div>

      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

<?php
    include "includes/footer.php";
?>

<?php  
 require_once "../../cnx.php";

 $messages = array();

 $recup_messages = $conn->query("SELECT * FROM an_categorie ORDER BY id DESC LIMIT 2 ");

 while ($all = $recup_messages->fetch_assoc()) 
 {
 	$messages[] = $all;
 	
 }?>
     <div class="card-body">
	            <table id="example1" class="table table-bordered table-striped">
	                <thead>
		                <tr>
		                  <th>Id</th>
		                  <th>Titre</th>
		                </tr>
	                </thead>
	                <tbody>
     <?php
 foreach ($messages as $message) {?>
 	     <tr>
 	     	<td><?php echo $message['id']; ?></td>
 	     	<td><?php echo $message['label']; ?></td>
 	     </tr>
 		
   <?php } ?>
                   </tbody>
		            <tfoot>
		                <tr>
		                  <th>Id</th>
		                  <th>Titre</th>
		                </tr>
	                </tfoot>
	            </table>
            </div>
    <?php 
    

?>
<?php
	require_once "../../cnx.php";

	if (isset($_POST['submit'])) {

		echo $title = $_POST['title'];
        
		$sql = "INSERT INTO `an_categorie` (`id`, `label`) VALUES ('', '".$title."') ";

		if ($conn->query($sql) === TRUE) {
			echo "New record created successfully";
		} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
		}
	}

	$conn->close();
?>
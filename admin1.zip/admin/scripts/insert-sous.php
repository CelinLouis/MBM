<?php
	require_once "../../cnx.php";

	if (isset($_POST['submit'])) {

		$title = $_POST['title'];
		 $cat = $_POST['cat'];
        
		$sql = "INSERT INTO `an_souscat` (`id`, `id_cat`, `label`) VALUES ('', '".$cat."', '".$title."') ";

		if ($conn->query($sql) === TRUE) {
			echo "New record created successfully";
		} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
		}
	}

	$conn->close();
?>
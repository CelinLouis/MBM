<?php 
     require_once "../../cnx.php";

     setlocale(LC_TIME, 'fr');

     if(isset($_POST['title']) && !empty($_POST['title'])){
     	$title = htmlspecialchars(trim($_POST['title']));

     	$conn->query(" INSERT INTO `an_categorie` (`id`, `label`) VALUES ('', '".$title."') ");
     	echo '<span> vos données ont été envoyée </span>';

           
     }else{
     	echo "<span style='color: red'> Veuillez completez les champs </span>" ;
     }

 ?>
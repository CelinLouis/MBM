-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 19, 2020 at 12:33 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `karoka_blablacar`
--

-- --------------------------------------------------------

--
-- Table structure for table `membres`
--

DROP TABLE IF EXISTS `membres`;
CREATE TABLE IF NOT EXISTS `membres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_type` varchar(20) NOT NULL DEFAULT 'particulier',
  `username` varchar(255) NOT NULL,
  `civility` varchar(5) NOT NULL,
  `name` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `region` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `post_code` varchar(10) NOT NULL,
  `city` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'en attente',
  `phone` varchar(20) NOT NULL,
  `comp_name` varchar(255) DEFAULT NULL,
  `comp_num` varchar(20) DEFAULT NULL,
  `term_cond` tinyint(1) NOT NULL DEFAULT 1,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membres`
--

INSERT INTO `membres` (`id`, `account_type`, `username`, `civility`, `name`, `first_name`, `email`, `region`, `address`, `post_code`, `city`, `status`, `phone`, `comp_name`, `comp_num`, `term_cond`, `password`) VALUES
(15, 'particulier', 'andrianflorio@gmail.com', 'Homme', 'Andrianarison', 'FLORIO', 'andrianflorio@gmail.com', 11, 'Antanimalandy', '401', 'Mahajanga', 'valide', '0328894556', NULL, NULL, 1, '$2y$10$GP1pbCFNqgE3JLXef/T3B.cjHC9D.IJM/CjN2SyATOIjP0JP7ETG2'),
(16, 'particulier', 'yaplukafer@gmail.com', 'Homme', 'Lucas', 'RENE', 'yaplukafer@gmail.com', 11, '27 RUE DU NIGER, PORTE A11', '75012', 'PARIS', 'en attente', '0325687059', NULL, NULL, 1, '$2y$10$zROZ6TJmZ4.YFaGHNht9Q.gArqQaZiPmY3er7ne/4uwdXZgzVd3PK'),
(17, 'particulier', 'tahiry@ok.com', 'Homme', 'Tahiry', 'FALI', 'tahiry@ok.com', 8, 'huzhu', '425', 'mahajanga', 'en attente', '0325698758', NULL, NULL, 1, '$2y$10$kfjmWLrXRmAwBBJKJfHas.kY4/r76onBPURp0YyQj.Xawnypjq8B2'),
(18, 'particulier', 'mcharryism@gmail.com', 'Homme', 'Salimo', 'HARRIS', 'mcharryism@gmail.com', 11, 'Majunga be', '401', 'Diego', 'en attente', '0325029021', NULL, NULL, 1, '$2y$10$tquKT4wt44jRSraVaVWtuOdmxtNyZvGUikxxDEXYeezZ46s7vbYV6');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

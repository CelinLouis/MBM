<?php
  session_start();
  require('inc/header.php');
?>
<title><?php echo strtoupper($_SESSION['f_name'])." ".strtoupper($_SESSION['name']); ?></title>
<div class="container-100 header-end"></div>
<div class="container-100" style="height:100%;">
  <div class="container-100-child index-container">
    <div class="search-form" method="get" action="search.php">
				<div class="container-100">
						<div class="container-100-child">

							<div>
                <h3>
								    Bienvenue <?php echo ucfirst(strtolower($_SESSION['name']))." ".ucfirst(strtolower($_SESSION['f_name'])); ?>
								</h3>
                
							</div>

						</div>
					</div>

			</div>
  </div>
</div>
<?php
  require('inc/footer.php');
?>
